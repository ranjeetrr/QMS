	
	function flicker(name) {
	
	var leftVal = 0;
	var rightVal = 0;
	var frontVal = 0;
	var backVal = 0;
	
	document.getElementById("hiddenData").value=name;
	var locationIdFrwd= document.getElementById("frwd");
	var locationIdLeft= document.getElementById("left");
	var locationIdRight= document.getElementById("right");
	var locationIdBack= document.getElementById("back");
	var locationIdOrigin= document.getElementById("origin");
			
	for(var i=0;i<id.length;i++)
	{
	if(id[i].location==name)
		{
			
			var flickerAPIFrwd = urlConcatFunction(id[i].origin,id[i].destinationFrwd);
			var flickerAPILeft = urlConcatFunction(id[i].origin,id[i].destinationLeft);
			var flickerAPIRight = urlConcatFunction(id[i].origin,id[i].destinationRight);
			var flickerAPIBack = urlConcatFunction(id[i].origin,id[i].destinationBack);
			
			locationIdFrwd.textContent=id[i].frwdLocation;
			locationIdLeft.textContent=id[i].leftLocation;
			locationIdRight.textContent=id[i].rightLocation;
			locationIdBack.textContent=id[i].backLocation;
			locationIdOrigin.textContent=id[i].location;
			
		}
	}	
  $.getJSON( flickerAPIFrwd, {
    tags: "routes",
    tagmode: "legs",	
    format: "json"
  })
  .done(function(data) {
	var IdealtimeFrwd=data.routes[0]['legs'][0]['duration']['value'];
	var TrafficTimeFrwd= data.routes[0]['legs'][0]['duration_in_traffic']['value'];
	var image = document.getElementById("myImage");
	
	var frwd =changeImage(IdealtimeFrwd,TrafficTimeFrwd);

	if(frwd=="green")
    {
		frontVal= -5;
		
		image.src = "D:/images/GreenFrwd.png";
	}
	else if(frwd=="yellow")
    {
		frontVal= 0;
		image.src = "D:/images/YellowFrwd.png";
	}
	else if(frwd=="red")
    {
		frontVal= 5;
		image.src = "D:/images/RedFrwd.png";
	}
	else 
    {
		frontVal= 10;
		image.src = "D:/images/MaroonFrwd.png";
	}
	//alert("Inside alert "+frontVal);
  });
  $.getJSON( flickerAPILeft, {
    tags: "routes",
    tagmode: "legs",	
    format: "json"
  })
  .done(function(data){
	var IdealtimeLeft=data.routes[0]['legs'][0]['duration']['value'];
	var TrafficTimeLeft=data.routes[0]['legs'][0]['duration_in_traffic']['value'];
	var imageLeft = document.getElementById("myImageLeft");
	var left=changeImage(IdealtimeLeft,TrafficTimeLeft); 

	if(left=="green")
    {
		document.getElementById("leftCounter").value= -5;
		imageLeft.src = "D:/images/GreenLeft.png";
	}
	else if(left=="yellow")
    {
		document.getElementById("leftCounter").value= 0;
		imageLeft.src = "D:/images/YellowLeft.png";
	}
	else if(left=="red")
    {
		document.getElementById("leftCounter").value= 5;
		imageLeft.src = "D:/images/RedLeft.png";
	}
	else 
    {
		document.getElementById("leftCounter").value= 10;
		imageLeft.src = "D:/images/MaroonLeft.png";
	}
  });
  $.getJSON( flickerAPIRight, {
    tags: "routes",
    tagmode: "legs",	
    format: "json"
  })
  .done(function (data){
	var IdealtimeRight=data.routes[0]['legs'][0]['duration']['value'];
	var TrafficTimeRight=data.routes[0]['legs'][0]['duration_in_traffic']['value'];
	var imageRight = document.getElementById("myImageRight");
	var right =changeImage(IdealtimeRight,TrafficTimeRight);

	if(right=="green")
    {
		document.getElementById("rightCounter").value= -5;
		imageRight.src = "D:/images/GreenRight.png";
	}
	else if(right=="yellow")
    {
		document.getElementById("rightCounter").value= 0;
		imageRight.src = "D:/images/YellowRight.png";
	}
	else if(right=="red")
    {
		document.getElementById("rightCounter").value= 5;
		imageRight.src = "D:/images/RedRight.png";
	}
	else 
    {
		document.getElementById("rightCounter").value= 10;
		imageRight.src = "D:/images/MaroonRight.png";
	}
  });
  $.getJSON( flickerAPIBack, {
    tags: "routes",
    tagmode: "legs",	
    format: "json"
  })
    .done(function( data ) {
       
		var IdealtimeBack=data.routes[0]['legs'][0]['duration']['value'];
		var TrafficTimeBack=data.routes[0]['legs'][0]['duration_in_traffic']['value'];
		var imageBack = document.getElementById("myImageBack");
		var back =changeImage(IdealtimeBack,TrafficTimeBack);
 
		if(back=="green")
		{
			document.getElementById("backCounter").value= -5;
			imageBack.src = "D:/images/GreenBack.png";
		}
		else if(back=="yellow")
		{
			document.getElementById("backCounter").value= 0;
			imageBack.src = "D:/images/YellowBack.png";
		}
		else if(back=="red")
		{
			document.getElementById("backCounter").value= 5;
			imageBack.src = "D:/images/RedBack.png";
		}
		else 
		{
			document.getElementById("backCounter").value= 10;
			imageBack.src = "D:/images/MaroonBack.png";
		}
     $.each( data.items, function( i, item ) {
                  //alert("ffff="+item[i]);
                
      $( "<img>" ).attr( "src", item.media.m ).appendTo( "#images" );
        if ( i === 3 ) {
        return false;
       }
		
		
      });
    });
	//alert("frontVal "+frontVal);
}
  
	  

function urlConcatFunction(origin,destination) {
   
   
 var time=getEpochTime();

    var res = "https://maps.googleapis.com/maps/api/directions/json?origin=place_id:"+origin+ "&destination=place_id:"+destination+"&departure_time="+time+"&traffic_model=best_guess&key=AIzaSyAAaU3Qptj2-0XTuRUgadUVUQE3ABhvIdM";
    
	return res;
}

 


function getEpochTime() {
    var epochTime = Math.round((new Date()).getTime() / 1000);
	return epochTime;
}


function changeImage(duration,duration_in_traffic) {

    var image = document.getElementById("myImage");
	
    if (duration_in_traffic < duration -10) {
		return "green";
    } else if (duration_in_traffic >= duration - 10 && duration_in_traffic <= duration + 10) {
		return "yellow";
    } else if (duration_in_traffic > duration  + 10 && duration_in_traffic <= duration  + (0.3*duration)) {
		return "red";
    } else {
		return "brown";
	}
}

function alertFunction(){

 alert(document.getElementById("frontCounter").value);
 alert(document.getElementById("backCounter").value);
 alert(document.getElementById("leftCounter").value);
 alert(document.getElementById("rightCounter").value);
 
}
